package com.javier.traductor

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Rect
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.WindowManager
import com.google.mlkit.nl.languageid.LanguageIdentification
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.Translator
import com.google.mlkit.nl.translate.TranslatorOptions
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.Text
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.util.Locale

/**
 * Captura la pantalla, hace OCR, traduce y dibuja la traducción encima.
 * Flujo: pantalla cambia -> se oculta la traducción vieja -> pantalla queda quieta
 * -> OCR -> detectar idioma por bloque -> traducir -> dibujar overlay.
 */
class ScreenTranslateService : Service() {

    companion object {
        const val ACTION_STOP = "com.javier.traductor.STOP"
        const val EXTRA_CODE = "code"
        const val EXTRA_DATA = "data"
        private const val CHANNEL = "traductor"
        private const val TICK_MS = 400L
        @Volatile var running = false
    }

    private val handler = Handler(Looper.getMainLooper())
    private lateinit var wm: WindowManager

    private var projection: MediaProjection? = null
    private var reader: ImageReader? = null
    private var display: VirtualDisplay? = null
    private var overlay: OverlayView? = null
    private var screenW = 0
    private var screenH = 0

    private val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    private val langId = LanguageIdentification.getClient()
    private val translators = HashMap<String, Translator>()
    private val cache = HashMap<String, String>()
    private val target: String =
        TranslateLanguage.fromLanguageTag(Locale.getDefault().language) ?: TranslateLanguage.SPANISH

    // Estado del ciclo
    private var busy = false
    private var dirty = false
    private var awaitBaseline = false
    private var lastHash = 0L
    private var frame: Bitmap? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (running) return START_NOT_STICKY

        startForegroundCompat()

        val code = intent?.getIntExtra(EXTRA_CODE, 0) ?: 0
        @Suppress("DEPRECATION")
        val data = intent?.getParcelableExtra<Intent>(EXTRA_DATA)
        if (data == null) {
            stopSelf()
            return START_NOT_STICKY
        }

        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        setupCapture(code, data)
        setupOverlay()
        running = true
        handler.postDelayed(tick, TICK_MS)
        return START_NOT_STICKY
    }

    private fun startForegroundCompat() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "Traducción de pantalla", NotificationManager.IMPORTANCE_LOW)
        )
        val stopIntent = PendingIntent.getService(
            this, 0,
            Intent(this, ScreenTranslateService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        val notif = Notification.Builder(this, CHANNEL)
            .setContentTitle("Traduciendo pantalla")
            .setContentText("Toca Detener para terminar")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .addAction(Notification.Action.Builder(null, "Detener", stopIntent).build())
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, notif, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else {
            startForeground(1, notif)
        }
    }

    @Suppress("DEPRECATION")
    private fun setupCapture(code: Int, data: Intent) {
        val dm = DisplayMetrics()
        wm.defaultDisplay.getRealMetrics(dm)
        screenW = dm.widthPixels
        screenH = dm.heightPixels

        val mpm = getSystemService(MediaProjectionManager::class.java)
        val p = mpm.getMediaProjection(code, data)
        // Android 14+: hay que registrar el callback antes de crear el VirtualDisplay
        p.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { stopSelf() }
        }, handler)
        projection = p

        val r = ImageReader.newInstance(screenW, screenH, PixelFormat.RGBA_8888, 2)
        reader = r
        display = p.createVirtualDisplay(
            "traductor", screenW, screenH, dm.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, r.surface, null, handler
        )
    }

    private fun setupOverlay() {
        val v = OverlayView(this)
        val lp = WindowManager.LayoutParams(
            screenW, screenH,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        if (Build.VERSION.SDK_INT >= 28) {
            lp.layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        wm.addView(v, lp)
        overlay = v
    }

    // ---------- Ciclo principal ----------

    private val tick = object : Runnable {
        override fun run() {
            if (!running) return
            step()
            handler.postDelayed(this, TICK_MS)
        }
    }

    private fun step() {
        val bmp = grab()
        if (bmp != null) {
            val h = hash(bmp)
            if (awaitBaseline) {            // primer frame después de pintar la traducción
                lastHash = h
                awaitBaseline = false
                bmp.recycle()
                return
            }
            if (h != lastHash) {            // la pantalla cambió (scroll, otra app...)
                lastHash = h
                frame?.recycle()
                frame = bmp
                overlay?.clear()            // ocultar traducción vieja
                dirty = true
            } else {
                bmp.recycle()
            }
            return
        }
        // Sin frame nuevo = pantalla quieta -> traducir el último frame limpio
        val f = frame
        if (dirty && !busy && f != null) {
            dirty = false
            frame = null
            translateFrame(f)
        }
    }

    private fun grab(): Bitmap? {
        val img = reader?.acquireLatestImage() ?: return null
        try {
            val p = img.planes[0]
            val rowPadding = p.rowStride - p.pixelStride * screenW
            val tmp = Bitmap.createBitmap(
                screenW + rowPadding / p.pixelStride, screenH, Bitmap.Config.ARGB_8888
            )
            tmp.copyPixelsFromBuffer(p.buffer)
            val out = Bitmap.createBitmap(tmp, 0, 0, screenW, screenH)
            if (out !== tmp) tmp.recycle()
            return out
        } finally {
            img.close()
        }
    }

    /** Huella barata de la pantalla (ignora la barra de estado y cambios mínimos de color). */
    private fun hash(b: Bitmap): Long {
        var h = 1125899906842597L
        val y0 = (b.height * 0.06).toInt()
        val stepX = maxOf(b.width / 48, 1)
        val stepY = maxOf((b.height - y0) / 72, 1)
        var y = y0
        while (y < b.height) {
            var x = 0
            while (x < b.width) {
                h = 31 * h + (b.getPixel(x, y) and 0xF0F0F0)
                x += stepX
            }
            y += stepY
        }
        return h
    }

    // ---------- OCR + traducción ----------

    private fun translateFrame(bmp: Bitmap) {
        busy = true
        recognizer.process(InputImage.fromBitmap(bmp, 0))
            .addOnSuccessListener { result ->
                val blocks = result.textBlocks.filter {
                    it.boundingBox != null && it.text.count { c -> c.isLetter() } >= 3
                }
                if (blocks.isEmpty()) finish(bmp, emptyList()) else translateBlocks(bmp, blocks)
            }
            .addOnFailureListener { finish(bmp, emptyList()) }
    }

    private fun translateBlocks(bmp: Bitmap, blocks: List<Text.TextBlock>) {
        val results = arrayOfNulls<String>(blocks.size)
        var pending = blocks.size
        blocks.forEachIndexed { i, block ->
            translateOne(block.text.replace('\n', ' ')) { out ->
                results[i] = out
                pending--
                if (pending == 0) {
                    val items = blocks.indices.mapNotNull { k ->
                        val text = results[k] ?: return@mapNotNull null
                        val r = blocks[k].boundingBox!!
                        val px = bmp.getPixel(
                            (r.left + 2).coerceIn(0, bmp.width - 1),
                            (r.top + 2).coerceIn(0, bmp.height - 1)
                        )
                        val bg = px or (0xFF shl 24)
                        val lum = 0.299 * Color.red(bg) + 0.587 * Color.green(bg) + 0.114 * Color.blue(bg)
                        OverlayView.Raw(Rect(r), text, bg, if (lum > 140) Color.BLACK else Color.WHITE)
                    }
                    finish(bmp, items)
                }
            }
        }
    }

    /** Detecta el idioma del texto y lo traduce; devuelve null si no hace falta traducir. */
    private fun translateOne(text: String, done: (String?) -> Unit) {
        cache[text]?.let { done(it); return }
        langId.identifyLanguage(text)
            .addOnSuccessListener { tag ->
                val src = if (tag == "und") null else TranslateLanguage.fromLanguageTag(tag)
                if (src == null || src == target) {
                    done(null)
                    return@addOnSuccessListener
                }
                val tr = translators.getOrPut(src) {
                    Translation.getClient(
                        TranslatorOptions.Builder()
                            .setSourceLanguage(src)
                            .setTargetLanguage(target)
                            .build()
                    )
                }
                tr.downloadModelIfNeeded(DownloadConditions.Builder().build())
                    .addOnSuccessListener {
                        tr.translate(text)
                            .addOnSuccessListener { out ->
                                if (cache.size > 500) cache.clear()
                                cache[text] = out
                                done(out)
                            }
                            .addOnFailureListener { done(null) }
                    }
                    .addOnFailureListener { done(null) }
            }
            .addOnFailureListener { done(null) }
    }

    private fun finish(bmp: Bitmap, items: List<OverlayView.Raw>) {
        busy = false
        bmp.recycle()
        // Si la pantalla cambió mientras traducíamos, descartar y reintentar
        if (dirty || !running) return
        overlay?.setItems(items)
        awaitBaseline = items.isNotEmpty()
    }

    override fun onDestroy() {
        running = false
        handler.removeCallbacksAndMessages(null)
        overlay?.let { runCatching { wm.removeView(it) } }
        display?.release()
        reader?.close()
        projection?.stop()
        recognizer.close()
        langId.close()
        translators.values.forEach { it.close() }
        frame?.recycle()
        super.onDestroy()
    }
}
