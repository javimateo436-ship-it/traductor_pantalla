package com.javier.traductor

import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private val reqProjection = 1001

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (24 * resources.displayMetrics.density).toInt()

        val info = TextView(this).apply {
            text = "1) Toca Iniciar.\n2) Acepta el permiso de superposición (solo la primera vez).\n" +
                "3) Acepta la captura de pantalla y elige \"Toda la pantalla\".\n" +
                "4) Abre cualquier app: la traducción aparece cuando la pantalla se queda quieta.\n\n" +
                "La primera vez necesita internet para bajar los idiomas."
            textSize = 16f
        }
        val start = Button(this).apply {
            text = "Iniciar traducción"
            setOnClickListener { startFlow() }
        }
        val stop = Button(this).apply {
            text = "Detener"
            setOnClickListener {
                stopService(Intent(this@MainActivity, ScreenTranslateService::class.java))
            }
        }

        setContentView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(pad, pad, pad, pad)
            addView(info)
            addView(start)
            addView(stop)
        })
    }

    private fun startFlow() {
        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 1002)
        }
        if (!Settings.canDrawOverlays(this)) {
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
            Toast.makeText(this, "Activa el permiso y vuelve a tocar Iniciar", Toast.LENGTH_LONG).show()
            return
        }
        val mpm = getSystemService(MediaProjectionManager::class.java)
        @Suppress("DEPRECATION")
        startActivityForResult(mpm.createScreenCaptureIntent(), reqProjection)
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == reqProjection && resultCode == RESULT_OK && data != null) {
            val i = Intent(this, ScreenTranslateService::class.java)
                .putExtra(ScreenTranslateService.EXTRA_CODE, resultCode)
                .putExtra(ScreenTranslateService.EXTRA_DATA, data)
            startForegroundService(i)
            moveTaskToBack(true)
        } else if (requestCode == reqProjection) {
            Toast.makeText(this, "Permiso de captura cancelado", Toast.LENGTH_SHORT).show()
        }
    }
}
