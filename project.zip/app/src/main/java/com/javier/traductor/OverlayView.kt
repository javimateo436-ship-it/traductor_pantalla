package com.javier.traductor

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Rect
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import android.view.View

/** Dibuja los textos traducidos encima del texto original. */
class OverlayView(ctx: Context) : View(ctx) {

    class Raw(val rect: Rect, val text: String, val bg: Int, val fg: Int)
    private class Item(val rect: Rect, val layout: StaticLayout, val bg: Int)

    private var items: List<Item> = emptyList()
    private val paint = Paint()
    private val minSize = 16f

    fun setItems(raw: List<Raw>) {
        items = raw.map { build(it) }
        invalidate()
    }

    fun clear() {
        items = emptyList()
        invalidate()
    }

    private fun build(r: Raw): Item {
        val pad = 4
        val rect = Rect(r.rect.left - pad, r.rect.top - pad, r.rect.right + pad, r.rect.bottom + pad)
        val w = rect.width().coerceAtLeast(10)
        val tp = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { color = r.fg }
        var size = minOf(rect.height().toFloat(), 56f).coerceAtLeast(minSize)
        var layout: StaticLayout
        do {
            tp.textSize = size
            layout = StaticLayout.Builder.obtain(r.text, 0, r.text.length, tp, w)
                .setAlignment(Layout.Alignment.ALIGN_NORMAL)
                .build()
            val fits = layout.height <= rect.height()
            if (!fits) size -= 2f
        } while (!fits && size >= minSize)
        return Item(rect, layout, r.bg)
    }

    override fun onDraw(canvas: Canvas) {
        for (item in items) {
            paint.color = item.bg
            canvas.drawRect(item.rect, paint)
            canvas.save()
            canvas.translate(item.rect.left.toFloat(), item.rect.top.toFloat())
            item.layout.draw(canvas)
            canvas.restore()
        }
    }
}
